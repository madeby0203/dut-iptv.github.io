from resources.lib.menu import plugin
plugin.dispatch(sys.argv[2])